import React from "react";
import LayoutDashBoard from "../../layouts/LayoutDashBoard";
import axios from "../../global/axios";
import { useTranslation } from "react-i18next";
import BootstrapTable from "react-bootstrap-table-next";
import ToolkitProvider, { Search } from "react-bootstrap-table2-toolkit";
import paginationFactory from "react-bootstrap-table2-paginator";
import ReactSelect from "react-select";

import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import { DatePicker, Space } from "antd";
import { Button } from "react-bootstrap";
import { useState } from "react";
import { useEffect } from "react";
import { Label } from "reactstrap";

const { SearchBar } = Search;
const { RangePicker } = DatePicker;
// const dateFormat = 'DD/MM/YYYY';

const tempData = [
  {
    rti_type_id: 220221012000007,
    paymentcategory_text: "RTI Fee",
    paymentname: "RTI Fee",
    paymentdate: "12/10/2022",
    amount: "10.0",
    payment_status: "S",
    payment_statustext: "Success",
    applicant_name_en: "AK",
    email_id: "n@gmail.com",
  },
];

const apiURL = process.env.REACT_APP_API_ENDPOINT;

function PaymentDetailsReport(props) {
  const [firstDate, setFirstDate] = useState(0);
  const [secondDate, setSecondtDate] = useState(0);
  const [rtiType, setRTItype] = useState(0);
  const [gettype, settype] = useState(0);
  const [paymentDetailsList, setPAYMENTDetailsList] = React.useState([]);
  const { t } = useTranslation("Layout");
  const [statustext, setStatusText] = React.useState("");
  const [Statedata,setState] =useState({
    mode: ['month', 'month'],
    value: [],
  })
  const s = props?.match?.params?.status;
  const ss = props?.match?.params?.status1;
  const token = sessionStorage.getItem("token");

  React.useEffect(() => {
    getPAYMENTDetailsList(0, firstDate, secondDate, rtiType);
  }, [props.location]);
  React.useEffect(() => {
    getPAYMENTDetailsList(gettype, firstDate, secondDate, rtiType);
  }, [gettype, firstDate, secondDate, rtiType]);
  console.log(paymentDetailsList);

  const getPAYMENTDetailsList = (status, firstDate, secondDate, rtiType) => {
    axios({
      method: "get",
      url: `${apiURL}/Admin/GetPaymentTransactions/${status}/${firstDate}/${secondDate}/${rtiType}`,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    })
      .then(function (response) {
        setPAYMENTDetailsList(response.data.table);
      })
      .catch(() => {});
  };

  

  const columns = [
    {
      dataField: "rti_type_id",
      text: t("paymentDetailsReport.rti_type_id", { framework: "React" }),
      sort: true,
    },

    // {
    //   dataField: "payment_category",
    //   text: t("paymentDetailsReport.payment_category", { framework: "React" }),
    //   sort: true,
    // },

    {
      dataField: "applicant_name_en",
      text: t("paymentDetailsReport.applicant_name_en", { framework: "React" }),
      sort: true,
    },

    {
      dataField: "email_id",
      text: t("paymentDetailsReport.email_id", { framework: "React" }),
      sort: true,
    },

    {
      dataField: "paymentname",
      text: t("paymentDetailsReport.paymentname", { framework: "React" }),
      sort: true,
    },

    {
      dataField: "amount",
      text: t("paymentDetailsReport.amount", { framework: "React" }),
      sort: true,
    },

    {
      dataField: "paymentdate",
      text: t("paymentDetailsReport.paymentdate", { framework: "React" }),
      sort: true,
    },

    {
      dataField: "payment_statustext",
      text: t("paymentDetailsReport.payment_statustext", {
        framework: "React",
      }),
      sort: true,
    },

    
  ];

  

  const options = [
    { value: "AF", label: "Additional Fees First Appeal (AF)" },
    { value: "AR", label: "Additional Fees RTI First Appeal (AR) " },
    { value: "FF", label: "First Appeal Fees (FF)" },
    { value: "OC", label: "Second Appeal Order Compensation Fees (OC)" },
    { value: "OP", label: "Second Appeal Order Penalty Fees (OP)" },
    { value: "RF", label: "RTI Fees (RF)" },
    { value: "SF", label: "Second Appeal Fees (SF)" },
  ];

  const options1 = [
    { value: "1", label: "RTI" },
    { value: "2", label: "First Appeal (FA) " },
    { value: "3", label: "Second Appeal (SA)" },
  ];

  const myComponent = () => {
    <select options={options} />;
  };

  const myComponent1 = () => {
    <select options={options1} />;
  };

  // const RangePicker = (e, a) => {
  //   const {value} = e;

  //   getPAYMENTDetailsList(value);
  // }

  const afterSearch = (newsearch) => {};

  const selectChange = (e, a) => {
    const { value } = e;
    settype(value);
    //getPAYMENTDetailsList(value, firstDate, secondDate, rtiType);
  };

  const selectRanger = (dates, dateStrings) => {
    console.log('From: ', dates[0], ', to: ', dates[1]);
  console.log('From: ', dateStrings[0], ', to: ', dateStrings[1]);
    // const {value} = e;
    // console.log(e)
      setFirstDate(dateStrings[0])
      setSecondtDate(dateStrings[1])
    // getPAYMENTDetailsList(value);
  };
  console.log(firstDate, secondDate);
  const DatePicker = (e, a) => {
    const { value } = e;
    //getPAYMENTDetailsList(value);
  };

  const selectChangeRTItype = (e, a) => {
    const { value } = e;
    setRTItype(value);
    //getPAYMENTDetailsList(value);
  };
  const handlePanelChange = (value, mode) => {
    setState({
      value,
      mode: [
        mode[0] === 'date' ? 'month' : mode[0],
        mode[1] === 'date' ? 'month' : mode[1],
      ],
    });
  };
  console.log("Statedata",Statedata)

  return (
    <LayoutDashBoard>
      <ul
        className="breadcrumb"
        style={{
          justifyContent: "center",
          position: "relative",
          marginBottom: 20,
        }}
      >
        <li>Payment Details Report</li>
      </ul>

      <div style={{ padding: 20 }}>
        <ToolkitProvider
          keyField="rti_type_id"
          data={paymentDetailsList}
          columns={columns}
          search={{ afterSearch }}
        >
          {(props) => (
            <div>
              <Row>
              <Label>ID Search</Label>
                <Col>
              <SearchBar {...props.searchProps} />
                </Col>
              </Row>
             

              <Row> 
              <Label >{t("paymentDetailsReport.paymentname", { framework: "React" })}</Label>
                <Col>
                  <ReactSelect options={options} onChange={selectChange} />
                </Col>
                <Label >{t("paymentDetailsReport.paymentdate", { framework: "React" })}</Label>
                <Col>
                  <Space direction="vertical" size={12}>
                    <RangePicker
                      DatePicker={DatePicker}
                      onChange={selectRanger}
                      onPanelChange={handlePanelChange}
                    />
                  </Space>
                </Col>
                <Label >{t("paymentDetailsReport.rti_type", { framework: "React" })}</Label>
                <Col>
                  <ReactSelect
                    options={options1}
                    onChange={selectChangeRTItype}
                  />
                </Col>
                {/* <Col>
                  <ReactSelect options={options} onChange={selectChange} />
                </Col> */}
              </Row>

              <hr />
              <BootstrapTable
                {...props.baseProps}
                bootstrap4
                pagination={paginationFactory({ sizePerPage: 30 })}
              />
            </div>
          )}
        </ToolkitProvider>
      </div>
    </LayoutDashBoard>
  );
}

export default PaymentDetailsReport;
